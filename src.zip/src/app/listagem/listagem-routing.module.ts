import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ListagemPage } from './listagem.page';

const routes: Routes = [
  {
    path: '',
    component: ListagemPage
  },
  {
    path: 'amigos-detail',
    redirectTo: '/listagem',
    pathMatch: 'full'
  },
  // {
  //   path: 'amigos-detail',
  //   loadChildren: () => import('./amigos-detail/amigos-detail.module').then( m => m.AmigosDetailPageModule)
  // },
  // Parte nova (para passar o :amigoId)
  {
    path: ':amigoId',
    loadChildren: () =>
    import('./amigos-detail/amigos-detail.module').then( m => m.AmigosDetailPageModule)
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ListagemPageRoutingModule {}

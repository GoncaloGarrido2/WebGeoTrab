import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AmigosDetailPageRoutingModule } from './amigos-detail-routing.module';

import { AmigosDetailPage } from './amigos-detail.page';
import { MapaModule } from 'src/app/mapa/mapa.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AmigosDetailPageRoutingModule,
    MapaModule
  ],
  declarations: [AmigosDetailPage]
})
export class AmigosDetailPageModule {}

import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AlertController } from '@ionic/angular';
import { Amigo } from '../amigo.model';
import { AmigosServiceService } from '../amigos-service.service';

@Component({
  selector: 'app-amigos-detail',
  templateUrl: './amigos-detail.page.html',
  styleUrls: ['./amigos-detail.page.scss'],
})
export class AmigosDetailPage implements OnInit {
  loadedAmigo: any;
  inputId: any;
  inputNome: any;
  inputFoto: any;
  constructor(
    private activatedRoute: ActivatedRoute,
    private amigosService: AmigosServiceService,
    private router: Router,
    private alertCtrl: AlertController
  ) {}
  ngOnInit() {

    this.activatedRoute.paramMap.subscribe((paramMap) => {
      if (!paramMap.has('amigoId')) {
        // redirect
        this.router.navigate(['/listagem']);
        return;
      } else {
        const amigoId = paramMap.get('amigoId');
        this.loadedAmigo = this.amigosService.getAmigo_RESTAPI(Number(amigoId));
        if(this.loadedAmigo == null || this.loadedAmigo.id == null) {
          this.router.navigate(['/listagem']);
        }
      }
    });
  }

  onDeleteAmigo() {
    this.alertCtrl
      .create({
        header: 'Confirmação',
        message: 'Deseja de facto eliminar permanentemente este registo de amigo?',
        buttons: [
          { text: 'Cancelar', role: 'cancel' },
          {
            text: 'Eliminar',
            handler: () => {
              this.amigosService.deleteAmigo(this.loadedAmigo.id);
              this.router.navigate(['/listagem']);
            },
          },
        ],
      })
      .then((alert) => alert.present());
  }
}

import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AmigosDetailPage } from './amigos-detail.page';

const routes: Routes = [
  {
    path: '',
    component: AmigosDetailPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AmigosDetailPageRoutingModule {}

import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Amigo } from './amigo.model';
import { AmigosServiceService } from './amigos-service.service';
import { AmigoMapaComponent } from '../amigo-mapa/amigo-mapa.component';

import { Observable, tap, map, catchError, of } from 'rxjs';
import { HttpClient, HttpParams } from '@angular/common/http';
@Component({
  selector: 'app-listagem',
  templateUrl: './listagem.page.html',
  styleUrls: ['./listagem.page.scss'],
})
export class ListagemPage implements OnInit {
@ViewChild(AmigoMapaComponent, {static:false})
childMap!: AmigoMapaComponent;
msgFromChildMap:any;
meusAmigos: Amigo[] = [];
msgErros = '';
novaInsercao: any;
inputId: any;
inputNome: any;
inputFoto: any;
private endpoint = 'http://localhost:62637/api'
  constructor(
    private activatedRoute: ActivatedRoute,
    private amigosService: AmigosServiceService,
    private httpClient: HttpClient) {
  }
  OnNewAmigo(){
    this.novaInsercao = true;
    setTimeout(()=>{
      this.msgFromChildMap = this.childMap.msgFromMapChild;
    },0);
  }
  buscarValorMapChild(){
    if(this.msgFromChildMap !== null && this.msgFromChildMap !== undefined){
      console.log(`buscarValorMapChild() = ${this.msgFromChildMap}`);

    }else{
      console.log(`buscarValorMapChild() = null/undefined`);
    }
  }
  OnCancelar() {
    this.novaInsercao = false;
  }

  OnAddNewAmigo() {
    this.novaInsercao = false;
    const novoAmigo: Amigo = new Amigo(this.inputId,this.inputNome,this.inputFoto);
    this.postRegisto(novoAmigo);
  }
  postRegisto(novoAmigo: Amigo){
    const params = new HttpParams()
    .set('inputId', novoAmigo.IdAmigo)
    .set('inputNome', novoAmigo.Nome)
    .set('inputFoto', novoAmigo.DataNascimento)
    // .set('lat', novoAmigo.Lat)
    // .set('lon', novoAmigo.Lon)

    return this.httpClient
      .post<Amigo>(
        this.endpoint + '/amigoinsert',
        null,
        { params: params })
      .pipe(
        (catchError(this.handleError<Amigo[]>(`Obter lista de amigos`)))
      )
      console.log()
  }
  handleError<T>(operation = 'operation', result?: T) {
    return (error: any): Observable<T> =>{
      console.error(error);
      console.log(`${operation} failed: ${error.message}`);
      return of(result as T);
    };
  }
  ngOnInit() {
    // this.meusAmigos = this.amigosService.getAmigos();
    this.activatedRoute.paramMap.subscribe(() => this.refresca());
  }

  refresca() {
    this.amigosService.getAmigos_RESTAPI().subscribe(resultado =>{
      if(resultado != null && resultado != undefined){
        this.meusAmigos = resultado;
        this.msgErros = 'Pronto';
      }else{
        this.msgErros = 'Erro no acesso ao serviço';
      }
    })
    this.meusAmigos = this.amigosService.getAmigos();
  }
}

import { Injectable } from '@angular/core';
import { Amigo } from './amigo.model';
import { Observable, tap, map, catchError, of } from 'rxjs';
import {HttpClient} from '@angular/common/http'

@Injectable({
  providedIn: 'root'
})
export class AmigosServiceService {

  private amigos: Amigo[] = [];

  private endpoint = 'http://localhost:62637/api'
  constructor(private httpClient: HttpClient) { }

  getAmigos() {
    return [...this.amigos];
  }
  getAmigos_RESTAPI():Observable<Amigo[]>{
    return this.httpClient.get<Amigo[]>(`${this.endpoint}/amigo`)
    .pipe(catchError(this.handleError<Amigo[]>(`Obter lista de amigos`)));
  }

  handleError<T>(operation = 'operation', result?: T) {
    return (error: any): Observable<T> =>{
      console.error(error);
      console.log(`${operation} failed: ${error.message}`);
      return of(result as T);
    };
  }
  getAmigo(amigoId: number) : Amigo | unknown {
    return {...this.amigos.find(a => a.IdAmigo === amigoId)};
  }
  getAmigo_RESTAPI(amigoId: number):Observable<Amigo[]>{
    return this.httpClient.get<Amigo[]>(`${this.endpoint}/amigouni?id=`+amigoId)
    .pipe(catchError(this.handleError<Amigo[]>(`Obter lista de amigos`)));
  }
  deleteAmigo(amigoId: any) {
    this.amigos = this.amigos.filter(a => a.IdAmigo !== amigoId);
  }
}

export class Amigo {
  IdAmigo: number;
  Nome: string;
  DataNascimento: string;
  contactos: string[];

  constructor(id: number, nome:string, imagem: string) {
    this.IdAmigo = id;
    this.Nome = nome;
    this.DataNascimento = imagem;
    this.contactos = [];
  }
  public toString(){
    return `${this.IdAmigo}= ${this.Nome}`
  }
}

import { AfterViewInit, Component, OnInit } from '@angular/core';
import * as L from 'leaflet';
@Component({
  selector: 'app-amigo-mapa',
  templateUrl: './amigo-mapa.component.html',
  styleUrls: ['./amigo-mapa.component.scss'],
})
export class AmigoMapaComponent  implements AfterViewInit {
  private marker: L.Marker | null = null;
private static map: L.Map;
msgFromMapChild: any[];
  constructor() {
    this.msgFromMapChild=[];

   }

  ngAfterViewInit(): void {
    this.initMapDefaultLeaflet();
    AmigoMapaComponent.map.on('click', (ev)=>{
      if(this.msgFromMapChild.length > 0){
        this.msgFromMapChild.pop();
        this.placeMarker(ev.latlng);
      }
      this.msgFromMapChild.push(ev.latlng);
    })
    AmigoMapaComponent.invalidadeSize();
  }
  static invalidadeSize() {
    setTimeout(()=>{
      AmigoMapaComponent.map.invalidateSize();
    },500);
  }
  private initMapDefaultLeaflet(): void {
    AmigoMapaComponent.map = L.map(`map`).setView(
      [41.233865, -8.622372],13
    );

    const titles= L.tileLayer(
      'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
      {maxZoom: 19,
       minZoom:3,
       attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>'
      }
    );
    titles.addTo(AmigoMapaComponent.map)


  }

  placeMarker(latlng: L.LatLng) {
    if (this.marker) {
      AmigoMapaComponent.map.removeLayer(this.marker);
    }

    this.marker = L.marker(latlng).addTo(AmigoMapaComponent.map);
  }

}

import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AmigoMapaComponent } from '../amigo-mapa/amigo-mapa.component';



@NgModule({
  declarations: [MapaModule.mapa],
  imports: [
    CommonModule
  ],
  exports:[MapaModule.mapa]
})
export class MapaModule {
  static mapa = AmigoMapaComponent;
}
